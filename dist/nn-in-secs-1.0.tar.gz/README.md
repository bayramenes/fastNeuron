# nn-in-secs
![Alt text](image.png)

## what is it ?

this is a hobby project to build a small framework to create and deploy neural networks quickly...

## how it all started ?
this is a project that i intended to make as an attempt to understand neural network and machine learning better...

i am a firm believer that building complex topics and ideas from scratch gives you a solid ground and grasp of the concepts...

## installation

Mac / Linux
```
pip3 install nn-in-secs
```

Windows
```
pip install nn-in-secs
```


## What can you do with it

Currently you can deploy any feed-forward neural network with any size2.

You can choose what optimizer to use ,which activations functions ,which cost function...


## NOTE: i am by no means an expert so if you have any improvements or found any bugs in the code please reach out!!